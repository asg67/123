const SingInBtn = document.querySelector('.signin-bnt');
const SingUpBtn = document.querySelector('.signup-bnt');
const formBox = document.querySelector('.form-box');
const body = document.body;

SingUpBtn.addEventListener('click', function () {
	formBox.classList.add('active');
	body.classList.add('active');
});

SingInBtn.addEventListener('click', function () {
	formBox.classList.remove('active');
	body.classList.remove('active');
});