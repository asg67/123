// var date = document.getElementById('date').value;
// var place = document.getElementById('place').value;

// var name_surname_buyer = document.getElementById('name_surname_buyer').value;
// var name_surname_salesman = document.getElementById('name_surname_salesman').value;

// var brand_of_model = document.getElementById('brand_of_model').value;
// var type_of_car = document.getElementById('type_of_car').value;

// var date_of_birth = document.getElementById('date_of_birth').value;

// var mode_of_engine = document.getElementById('mode_of_engine').value;
// var number_of_engine = document.getElementById('number_of_engine').value;

// var number_of_frame = document.getElementById('number_of_frame').value;

// var number_of_body = document.getElementById('number_of_body').value;


// var km = document.getElementById('km').value;
// var color = document.getElementById('color').value;
// var pts_of_series = document.getElementById('pts_of_series').value;
// var pts_of_number = document.getElementById('pts_of_number').value;

// var pts_date = document.getElementById('pts_date').value;
// var sts_series = document.getElementById('sts_series').value;
// var sts_number = document.getElementById('sts_number').value;
// var cost_of_car = document.getElementById('cost_of_car').value;
// var series_passport_salesman = document.getElementById('series_passport_salesman').value;

// var number_passport_salesman = document.getElementById('number_passport_salesman').value;
// var date_passport_salesman = document.getElementById('date_passport_salesman').value;
// var kem_vad_passport_salesman = document.getElementById('kem_vad_passport_salesman').value;
// var adr_reg_passport_salesman = document.getElementById('adr_reg_passport_salesman').value;

// var series_passport_buyer = document.getElementById('series_passport_buyer').value;
// var number_passport_buyer = document.getElementById('number_passport_buyer').value;
// var date_passport_buyer = document.getElementById('date_passport_buyer').value;
// var kem_vad_passport_buyer = document.getElementById('kem_vad_passport_buyer').value;
// var adr_reg_date_passport_buyer = document.getElementById('adr_reg_date_passport_buyer').value;

// var str = `Место составления:  		${place}												Дата составления:  ${date}\
// 								Договор купли-продажи транспортного средства\
// 			Мы,             ${name_surname_salesman}                               заключили настоящий договор о нижеследующем:, именуемый(ая) в дальнейшем «Продавец», \
// 			и ,             ${name_surname_buyer}                                  именуемый(ая) в дальнейшем «Покупатель»,\
// 	  Договор купли-продажи транспортного средства\
// 	  1.1. Продавец передает принадлежащее ему на праве собственности транспортное средство (в дальнейшем ТС) покупателю, а покупатель \
// 	  принимает указанное транспортное средство и обязуется уплатить за него денежную сумму, указанную в п.2 настоящего договора.\
// 	  Марка и модель ТС    ${brand_of_model}                                                                          \
// 	  VIN				   ${vin}						    	   Регистрационный знак\
// 	  Тип ТС			   ${type_of_car}						   Год изготовления     ${date_of_birth}        Пробег, км     ${km}\
// 	  Модель, No двигателя ${mode_of_engine} ${number_of_engine}   Номер шасси, рама    ${number_of_frame}  \
// 	  Номер кузова		   ${number_of_body}					   Цвет кузова   ${color}                    \               
// 	  ПТС:  ${pts_of_series}  ${pts_of_number}      выдан   ${pts_date}                           \
// 	  СТС:  ${sts_series}     ${sts_number}         выдан   ${sts_date}                                       \
// 	                                                                                                   														\
// 																2. Цена ТС\
// 	Цена продажи указанного ТС составляет                ${cost_of_car}                                                          рублей\
// 																																					\
// 															3. Ответственность и гарантии\
// 	3.1. ТС передано продавцом и принято покупателем при заключении сторонами настоящего договора. ТС пригодно для использования по его целевому назначению. Претензий по техническому состоянию, состоянию кузова и характеристикам (качеству) ТС покупатель не имеет. Отдельного документа о передаче ТС сторонами не составляется.\
// 	3.2. Продавец гарантирует, что на дату заключения настоящего договора указанное ТС находится у него в собственности на законном основании, свободно от прав третьих лиц, никому не продано, не подарено, не заложено, в споре и под арестом (запрещением) не состоит, ограничения в пользовании ТС отсутствуют.\
// 	3.3. Покупатель и продавец подтверждают, что не состоят под опекой и попечительством, не страдают заболеваниями, препятствующими осознать суть договора, а также отсутствуют обстоятельства, вынуждающие совершить данный договор на крайне невыгодных условиях.\
// 	3.4. Настоящий договор вступает в силу с момента подписания и составлен в трех экземплярах, имеющих равную юридическую силу. Настоящий договор действует до полного исполнения сторонами принятых на себя обязательств.\
// 																																																				\
// 	Продавец:   ${name_surname_salesman}               																			Покупатель: 	${name_surname_buyer}												 \
// 	Паспорт: серия  ${series_passport_salesman} номер  ${number_passport_salesman}  дата выдачи   ${date_passport_salesman}		Паспорт: серия  ${series_passport_buyer}    номер ${number_passport_buyer}    дата выдачи   ${date_passport_buyer}                    	  \
// 	Кем выдан      ${kem_vad_passport_salesman}       																			Кем выдан   ${kem_vad_passport_buyer}                                                       \
// 	Адрес регистрации  ${adr_reg_passport_salesman}                                                 							Адрес регистрации    ${adr_reg_date_passport_buyer}                             					\
// 	         			/																	   									 							/													 \
// 	Подпись                     Расшифровка        																							Подпись                     Расшифровка				                  `



function button() {
	var place = document.getElementById('place').value;

	var name_surname_buyer = document.getElementById('name_surname_buyer').value;
	var name_surname_salesman = document.getElementById('name_surname_salesman').value;

	var brand_of_model = document.getElementById('brand_of_model').value;
	var type_of_car = document.getElementById('type_of_car').value;

	var date_of_birth = document.getElementById('date_of_birth').value;

	var mode_of_engine = document.getElementById('mode_of_engine').value;
	var number_of_engine = document.getElementById('number_of_engine').value;

	var number_of_frame = document.getElementById('number_of_frame').value;

	var number_of_body = document.getElementById('number_of_body').value;


	var km = document.getElementById('km').value;
	var color = document.getElementById('color').value;
	var pts_of_series = document.getElementById('pts_of_series').value;
	var pts_of_number = document.getElementById('pts_of_number').value;

	var pts_date = document.getElementById('pts_date').value;
	var sts_series = document.getElementById('sts_series').value;
	var sts_number = document.getElementById('sts_number').value;
	var cost_of_car = document.getElementById('cost_of_car').value
	var series_passport_salesman = document.getElementById('series_passport_salesman').value;

	var number_passport_salesman = document.getElementById('number_passport_salesman').value;
	var date_passport_salesman = document.getElementById('date_passport_salesman').value;
	var kem_vad_passport_salesman = document.getElementById('kem_vad_passport_salesman').value;
	var adr_reg_passport_salesman = document.getElementById('adr_reg_passport_salesman').value;

	var series_passport_buyer = document.getElementById('series_passport_buyer').value;
	var number_passport_buyer = document.getElementById('number_passport_buyer').value;
	var date_passport_buyer = document.getElementById('date_passport_buyer').value;
	var kem_vad_passport_buyer = document.getElementById('kem_vad_passport_buyer').value;
	var adr_reg_date_passport_buyer = document.getElementById('adr_reg_date_passport_buyer').value;
	
}







