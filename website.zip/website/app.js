const mysql = require('mysql');


const conn = mysql.net.createConnection(config {
	host: 'itgid.mysql.tools',
	user: 'itgid_nodetest',
	database: 'itgid_nodecourse',
	password: 'Al6gAi50YiB0'
});


conn.connect(err =>	{
	if (err) {
		console.log(err);
		return err;
	}
	else {
		console.log('Database ----- OK');
	}
})


let query = "SELECT * FROM user"
conn.query(query, (err, result, field) => {
	console.log(err);
	console.log(result);	
})